<?php
	session_start();

?>

<!doctype html>
<html lang="en" >

	<head>
		<meta charset="utf-8" />
		<title> <?php echo( $_SERVER["PHP_SELF"] ); ?> Roll the dice...</title>
		<link href="style/style.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>

	<body>
	
		<div>
			<?php
				$disabled = true;
				
				//Var uppmärksam på att PHP-tolken används på ett flertal ställen i filen!
				//Krav 1
				if(isset($_GET["linkNewGame"])) {
					echo("<h2> New Game </h2>" );
					$_SESSION["nbrOfRounds"] = 0;
					$_SESSION["sumOfAllRounds"] = 0;
					echo $_SESSION["nbrOfRounds"] . $_SESSION["sumOfAllRounds"];
					$disabled = false;
				}

				//Krav 2
				if(isset($GET["linkExit"]) && isset($_SESSION["nbrOfRounds"]) && isset($_SESSION["sumOfAllRounds"]))  {
					//ta bort session-variabler
					session_unset();

					//avslutar session
					session_destroy();
				}
				
				//Krav 3
				if(!isset($GET["linkNewGame"]) && !isset($GET["linkRoll"] ) && !isset($GET["linkExit"]) && !isset($_SESSION["nbrOfRounds"]) && !isset($_SESSION["sumOfAllRounds"])) {
					session_destroy();
				}

				//Krav 4
				if(!isset($GET["linkNewGame"]) && !isset($GET["linkRoll"] ) && !isset($GET["linkExit"]) && isset($_SESSION["nbrOfRounds"]) && isset($_SESSION["sumOfAllRounds"])) {

				}

				//Krav 5
				if(isset($_GET["linkRoll"]) && isset($_SESSION["nbrOfRounds"]) && isset($_SESSION["sumOfAllRounds"])) {
					
					include("include/OneDice.php");
					include("include/SixDices.php");

					$oSixDices = new SixDices();
					$oSixDices->rollDices();
					
					echo($oSixDices->svgDices());
				}

				//Krav 6
				if(!isset($_SESSION["nbrOfRounds"]) && !isset($_SESSION["sumOfAllRounds"])){
					$disabled = true;
				}


			?>
		</div>
		
		<a href="<?php ?>?linkRoll=true" class="btn btn-primary<?php if ($disabled) { echo("disabled");} ?>">Roll six dices</a>
		<a href="<?php ?>?linkNewGame=true" class="btn btn-primary">New game</a>
		<a href="<?php ?>?linkExit=true" class="btn btn-primary<?php if ($disabled) { echo("disabled");}?>">Exit</a>
		
		<script src="script/animation.js"></script>
		
	</body>

</html>