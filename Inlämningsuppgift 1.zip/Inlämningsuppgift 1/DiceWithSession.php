<?php
	session_start();
?>

<!doctype html>
<html lang="en" >

	<head>
		<meta charset="utf-8" />
		<title> <?php echo( $_SERVER["PHP_SELF"] ); ?> Roll the dice...</title>
		<link href="style/style.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>

	<body>
	
		<div>
			<?php
				$disabled = true;
				

				//Var uppmärksam på att PHP-tolken används på ett flertal ställen i filen!

				if(isset($_GET["linkNewGame"])) {
					echo("<h2> NEW GAME </h2>" );
					$_SESSION["nbrOfRounds"] = 0;
					$_SESSION["sumOfAllRounds"] = 0;
					$disabled= false;
				}

				if(isset($_GET["linkRoll"])) {
					echo("funkar");
					$disabled= false;
				}

			?>
		</div>
		
		<a href="<?php ?>?linkRoll=true" class="btn btn-primary<?php if ($disabled) { echo( $status?'disabled':'disabled');} ?>">Roll six dices</a>
		<a href="<?php ?>?linkNewGame=true" class="btn btn-primary">New game</a>
		<a href="<?php ?>?linkExit=true" class="btn btn-primary<?php ?>">Exit</a>
		
		<script src="script/animation.js"></script>
		
	</body>

</html>