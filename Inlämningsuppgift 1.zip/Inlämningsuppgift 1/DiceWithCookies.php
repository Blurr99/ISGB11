<!doctype html>
<html lang="en" >

	<head>
		<meta charset="utf-8" />
		<title> <?php echo( $_SERVER["PHP_SELF"] ); ?>Roll the dice...</title>	
		<link href="style/style.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>

	<body>
	
		<div>
			<?php
				$disabled = false;

				if( isset( $_POST["btnNewGame"] ) ) {
					setcookie( "CookieCourseCode", "ISGB11", time() + 3600 );
					$disabled = false;
					echo("<h2> NEW GAME </h2>");
					
					setcookie( "nbrOfRounds", 0, time() + 3600, "/" );
					setcookie( "sumOfAllRounds", 0, time() + 3600, "/");
				}

				if( !isset($_POST["btnNewGame"]) && !isset( $_POST["btnRoll"] )  && !isset( $_POST["btnExit"]) && isset($_COOKIE["nbrOfRounds"]) && isset($_COOKIE["sumOfAllRounds"])){
					echo("<p>" .$_COOKIE["nbrOfRounds"]. "</p>");
					echo("<p>" .$_COOKIE["sumOfAllRounds"]. "</p>");
					$counter = $_COOKIE["nbrOfRounds"];
					$totalSum = $_COOKIE["sumOfAllRounds"];
					$mean_value = $totalSum / $counter;
					echo("<p>".$mean_value. "</p>");	
				}

				if( isset( $_POST["btnRoll"]) && isset($_COOKIE["nbrOfRounds"]) && isset($_COOKIE["sumOfAllRounds"] ) ){
					echo("<p>" . $_POST["btnRoll"] . "</p>");
					
					include("include/OneDice.php");
					include("include/SixDices.php");

					$oSixDices = new SixDices();
					$oSixDices->rollDices();
					
					echo($oSixDices->svgDices());
					
					$sum = $oSixDices-> sumDices();

					$counter = $_COOKIE["nbrOfRounds"];
					$counter++;
					setcookie("nbrOfRounds", $counter, time() + 3600, "/");
					
					$totalSum = $_COOKIE["sumOfAllRounds"];
					$totalSum = $totalSum + $sum;
					setcookie("sumOfAllRounds", $totalSum, time() + 3600, "/");

					$mean_value = $totalSum / $counter;
					echo("<p>" . "Medelvärde: " . $mean_value . "</p>");
					echo("<p>" . "Antal kast: " . $counter . "</p>");
					echo("<p>" . "Summan av alla kast: " . $totalSum . "</p>");
				}

				if( isset( $_COOKIE["CookieCourseCode"] ) ) {
					$disabled = false;
				}

				if( !isset( $_POST["btnNewGame"] ) && !isset( $_POST["btnRoll"] ) && !isset( $_COOKIE["CookieCourseCode"] ) ) {
					$disabled = true;
				}

				if(isset($_POST["btnExit"]) && isset($_COOKIE["nbrOfRounds"]) && isset($_COOKIE["sumOfAllRounds"])) {
					$disabled=true;
					setcookie("nbrOfRounds", null, -1, "/");
					setcookie("sumOfAllRounds", null, -1, "/");
				}

				if( !isset($_COOKIE["nbrOfRounds"]) && !isset($_COOKIE["sumOfAllRounds"])) {
					$disabled = true;
				}
				
				
			?>
		</div>
		<form action="<?php echo( $_SERVER["PHP_SELF"] );?>" method="post">
			<input type="submit" name="btnRoll" class="btn btn-primary" value="Roll six dices" <?php if( $disabled ) { echo( "disabled='disabled'" ); }  ?>/>
			<input type="submit" name="btnNewGame" class="btn btn-primary" value="New Game" />
			<input type="submit" name="btnExit" class="btn btn-primary" value="Exit" <?php if($disabled) {echo("disabled='disabled'");}?>/>
		</form>

		<script src="script/animation.js"></script>
	</body>

</html>