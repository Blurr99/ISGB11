<!doctype html>
<html lang="en" >

	<head>
		<meta charset="utf-8" />
		<title> <?php echo( $_SERVER["PHP_SELF"] ); ?>Roll the dice...</title>	
		<link href="style/style.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>

	<body>
	
		<div>
			<?php

				echo( $_SERVER["PHP_SELF"] );

				$disabled = false;
				
				//Var uppmärksam på att PHP-tolken används på ett flertal ställen i filen!
				/*if(isset($_POST["btnRoll"])){
					
					echo("<p>". $_POST["btnRoll"] . "</p>");
					
					include("include/OneDice.php");
					include("include/SixDices.php");

					$oSixDices = new SixDices();
					$oSixDices->rollDices();
					

					echo("<p>" . $oSixDices-> sumDices() ."</p>");
					
					echo($oSixDices->svgDices());
				
				} */

				echo( $_SERVER["PHP_SELF"] );

				if( isset( $_POST["btnNewGame"] ) ) {
					setcookie( "CookieCourseCode", "ISGB11", time() + 3600 );
					$disabled = false;
					echo("<h2> NEW GAME </h2>");
					
					setcookie( "nbrOfRounds", 0, time() + 3600, "/" );
					setcookie( "sumOfAllRounds", 0, time() + 3600, "/");
				}

			

				if( !isset($_POST["btnNewGame"]) && !isset( $_POST["btnRoll"] )  && !isset( $_POST["btnExit"]) && isset($_COOKIE["nbrOfRounds"]) && isset($_COOKIE["sumOfAllRounds"])){
					echo("<p> hej </p>");
					echo("<p>" .$_COOKIE["nbrOfRounds"]. "</p>");
					echo("<p>" .$_COOKIE["sumOfAllRounds"]. "</p>");
					
				}

				if( isset( $_POST["btnRoll"] ) ) {
					echo("<p>". $_POST["btnRoll"] . "</p>");
					
					include("include/OneDice.php");
					include("include/SixDices.php");

					$oSixDices = new SixDices();
					$oSixDices->rollDices();
					

					echo("<p>" . $oSixDices-> sumDices() ."</p>");
					
					echo($oSixDices->svgDices());
					
					$counter = $_COOKIE["nbrOfRounds"];
					$counter++;
					$_COOKIE["nbrOfRounds"] = $counter;
					
					$totalSum = $_COOKIE["sumOfAllRounds"];
					$totalSum = $totalSum + $oSixDices-> sumDices() ;
					$_COOKIE["sumOfAllRounds"] = $totalSum;

					//$mean_value = ($_COOKIE["sumOfAllRounds"]) / ($_COOKIE["nbrOfRounds]);
					
					echo("<p>" . $_COOKIE["nbrOfRounds"] . "</p>");
					echo("<p>" . $_COOKIE["sumOfAllRounds"] . "</p>");
				}

				if( isset( $_COOKIE["CookieCourseCode"] ) ) {
					$disabled = false;
				}

				if( !isset( $_POST["btnNewGame"] ) && !isset( $_POST["btnRoll"] ) && !isset( $_COOKIE["CookieCourseCode"] ) ) {
					$disabled = true;
				}

				if(isset($_POST["btnExit"])) {
					exit("Spelet avslutas");
				}
				
				
			?>
		</div>
		<form action="<?php echo( $_SERVER["PHP_SELF"] );?>" method="post">
			<input type="submit" name="btnRoll" class="btn btn-primary" value="Roll six dices" <?php if( $disabled ) { echo( "disabled='disabled'" ); }  ?>/>
			<input type="submit" name="btnNewGame" class="btn btn-primary" value="New Game" />
			<input type="submit" name="btnExit" class="btn btn-primary" value="Exit" <?php if($disabled) {echo("disabled='disabled'");}?>/>
		</form>

		<script src="script/animation.js"></script>
	</body>

</html>